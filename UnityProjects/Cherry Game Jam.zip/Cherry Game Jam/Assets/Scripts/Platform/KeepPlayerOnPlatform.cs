﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class KeepPlayerOnPlatform : MonoBehaviour {

    //These two functions just make the player stay on the platform.
    void OnCollisionEnter(Collision other)
    {
        if (other.rigidbody != null)
        {
            //The other object movement now is linked to the platform.
            other.transform.parent = transform;
        }
    }

    void OnCollisionExit(Collision other)
    {
        if (other.rigidbody != null)
        {
            //The other object parent is set to null to be free movement.
            other.transform.parent = null;
        }
    }
}
